package sprint


import "math"

func Casting(n float64) int {
	return int(math.Round(n))
}