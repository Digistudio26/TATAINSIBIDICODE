package sprint
func GetFirstRune(s string) rune {
	for _, r := range s {
		return r
	}
	return 0
}


