package main
func Mean(a, b, c float32) float32 {
      return (( a + b + c ) /3)
}
