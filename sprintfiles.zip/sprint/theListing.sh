ls --format=commas -u --classify 
