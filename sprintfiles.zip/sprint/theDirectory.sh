
cd theDirectory
cd left
cd down
cd beginning
cat README
pwd
