package main

func NRune(s string, i int) rune {
	runes := []rune(s)
	return runes[i]
}