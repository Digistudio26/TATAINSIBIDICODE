
result=$(find . | wc -l)
multiple=$((result * 5))
printf "\t\vTotal files * 5: %d\v\n" "$multiple"
 



