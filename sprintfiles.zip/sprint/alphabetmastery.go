package main

func AlphabetMastery(n int) string {
	alphabet := "abcdefghijklmnopqrstuvwxyz"
	return alphabet[:n]
}