package sprint

func IsNegative(n int) bool {
	return n < 0
}
