// You can edit this code!
// Click here and start typing.
package main

func main() {
	println(Abacus(20, 10))
}
func Abacus(a int, b int) int {
	return a / b
}
