grep -wc "not" hay.txt
